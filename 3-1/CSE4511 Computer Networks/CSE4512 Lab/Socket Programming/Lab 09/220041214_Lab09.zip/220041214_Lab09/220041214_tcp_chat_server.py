import socket
import threading
import logging
import sys

logging.basicConfig(
    filename='server.log',
    level=logging.INFO,
    format='%(asctime)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

PORT = 6006
if len(sys.argv) == 2:
    PORT = int(sys.argv[1])

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
server.bind(('0.0.0.0', PORT))
server.listen(5)

print(f"Server Started on Port {PORT}")
logging.info(f"Server Started on Port {PORT}")

clients = []
client_info = {}
client_counter = 1

def broadcast(message, sender):
    for client in clients[:]:
        if client != sender:
            try:
                client.sendall(message)
            except:
                clients.remove(client)
    logging.info("Message Broadcasted")

def send_private(target_id, message, sender_conn):
    for conn, info in client_info.items():
        if str(info["id"]) == target_id:
            try:
                conn.sendall(message)
            except:
                pass
            return
    sender_conn.sendall(b"User not found.\n")

def handleClient(conn, addr):
    global client_counter

    print("Connected by:", addr)
    logging.info(f"Connected by {addr}")

    cid = client_counter
    client_counter += 1

    client_info[conn] = {
        "id": cid,
        "nick": f"User{cid}"
    }

    clients.append(conn)

    try:
        while True:
            data = conn.recv(1024)

            if not data:
                break

            msg = data.decode().strip()
            nick = client_info[conn]["nick"]

            if msg.startswith("/nick "):
                new_nick = msg.split(" ", 1)[1].strip()
                client_info[conn]["nick"] = new_nick
                conn.sendall(f"Nickname set to {new_nick}\n".encode())
                logging.info(f"{addr} set nick to {new_nick}")
                continue

            if msg.startswith("/msg "):
                parts = msg.split(" ", 2)
                if len(parts) < 3:
                    conn.sendall(b"Usage: /msg <id> <text>\n")
                    continue

                target_id = parts[1]
                text = parts[2]
                private_msg = f"[Private Message from {nick}] {text}\n".encode()
                send_private(target_id, private_msg, conn)
                continue

            full_msg = f"[{nick}] {msg}\n"
            print(f"Received from {addr}: {msg}")
            logging.info(full_msg.strip())

            broadcast(full_msg.encode(), conn)

    except:
        pass

    print("Disconnected:", addr)
    logging.info(f"Disconnected: {addr}")

    if conn in clients:
        clients.remove(conn)
    
    if conn in client_info:
        del client_info[conn]

    conn.close()

try:
    while True:
        conn, addr = server.accept()

        thread = threading.Thread(
            target=handleClient,
            args=(conn, addr),
            daemon=True
        )
        thread.start()

except KeyboardInterrupt:
    print("\nShutting down server.")
    logging.info("Server shutting down.")
    server.close()