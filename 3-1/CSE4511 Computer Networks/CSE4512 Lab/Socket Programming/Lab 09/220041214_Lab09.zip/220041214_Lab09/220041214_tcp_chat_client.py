import socket
import threading
import sys
from udp_discover import start_presence

if len(sys.argv) != 3:
    print("Usage: python3 tcp_chat_client.py <server_ip> <port>")
    sys.exit()

server_ip = sys.argv[1]
port = int(sys.argv[2])

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

try:
    client.connect((server_ip, port))
except Exception as e:
    print("Connection failed:", e)
    sys.exit()

print(f"Connected to ChatIUT server at {server_ip}:{port}")
start_presence("Anonymous")
print("Type /nick <msg> to set display names.")
print("Type /msg <client-id> <text> to message privately.")
print("Type /quit to exit.")

def receive():
    while True:
        try:
            data = client.recv(1024)

            if not data:
                print("\nServer disconnected.")
                break

            print(data.decode(), end="")
        except:
            break

def send():
    while True:
        try:
            message = input()

            if message == '/quit':
                client.close()
                break

            if message.startswith("/nick "):
                new_nick = message.split(" ", 1)[1].strip()
                start_presence(new_nick)

            if message.strip():
                client.sendall(message.encode())
        except KeyboardInterrupt:
            client.close()
            break
        except:
            break

receive_thread = threading.Thread(target=receive, daemon=True)
receive_thread.start()

send_thread = threading.Thread(target=send)
send_thread.start()

send_thread.join()

print("Disconnected from Server")