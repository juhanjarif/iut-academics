import socket
import threading
import time

UDP_PORT = 7007
BROADCAST_IP = "255.255.255.255"

def presence_sender(nickname):
    """
    Periodically broadcast presence message.
    Runs in a daemon thread.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

    message = f"PRESENCE:{nickname}".encode()

    while True:
        try:
            sock.sendto(message, (BROADCAST_IP, UDP_PORT))
            time.sleep(5)
        except:
            break


def start_presence(nickname):
    """
    Calling this from client to start UDP presence.
    """
    thread = threading.Thread(
        target=presence_sender,
        args=(nickname,),
        daemon=True
    )
    thread.start()