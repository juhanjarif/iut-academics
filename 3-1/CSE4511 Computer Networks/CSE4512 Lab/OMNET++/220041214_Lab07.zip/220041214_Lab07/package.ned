package hello_burger_network.simulations;

import inet.networklayer.configurator.ipv4.Ipv4FlatNetworkConfigurator;
import inet.networklayer.configurator.ipv4.Ipv4NetworkConfigurator;
import inet.node.ethernet.EthernetSwitch;
import inet.node.inet.Router;
import inet.node.inet.StandardHost;
import ned.IdealChannel;
import inet.node.ethernet.Eth100M;


@license(LGPL);
//
// TODO documentation
//
network helloBurgerNetwork
{
    @display("bgb=1537,732");
    submodules:
        router: Router {
            @display("p=558,267");
        }
        engineeringSwitch: EthernetSwitch {
            @display("p=363,266");
        }
        adminSwitch: EthernetSwitch {
            @display("p=795,425");
        }
        marketingSwitch: EthernetSwitch {
            @display("p=382,423");
        }
        salesSwitch: EthernetSwitch {
            @display("p=754,266");
        }
        managementSwitch: EthernetSwitch {
            @display("p=558,137");
        }
        engineeringHost1: StandardHost {
            @display("p=190,160");
        }
        engineeringHost2: StandardHost {
            @display("p=190,267");
        }
        engineeringHost3: StandardHost {
            @display("p=191,371");
        }
        managementHost1: StandardHost {
            @display("p=381,55");
        }
        managementHost2: StandardHost {
            @display("p=558,41");
        }
        managementHost3: StandardHost {
            @display("p=743,63");
        }
        salesHost1: StandardHost {
            @display("p=920,147");
        }
        salesHost2: StandardHost {
            @display("p=920,256");
        }
        salesHost3: StandardHost {
            @display("p=931,370");
        }
        adminHost1: StandardHost {
            @display("p=681,534");
        }
        adminHost2: StandardHost {
            @display("p=795,532");
        }
        adminHost3: StandardHost {
            @display("p=920,532");
        }
        marketingHost1: StandardHost {
            @display("p=231,523");
        }
        marketingHost2: StandardHost {
            @display("p=381,523");
        }
        marketingHost3: StandardHost {
            @display("p=532,523");
        }
        configurator: Ipv4NetworkConfigurator {
            @display("p=114,62");
            addStaticRoutes = false;
        }
    connections:
        engineeringHost1.ethg++ <--> Eth100M <--> engineeringSwitch.ethg++;
        engineeringHost2.ethg++ <--> Eth100M <--> engineeringSwitch.ethg++;
        engineeringHost3.ethg++ <--> Eth100M <--> engineeringSwitch.ethg++;
        managementHost1.ethg++ <--> Eth100M <--> managementSwitch.ethg++;
        managementHost2.ethg++ <--> Eth100M <--> managementSwitch.ethg++;
        managementHost3.ethg++ <--> Eth100M <--> managementSwitch.ethg++;
        salesHost1.ethg++ <--> Eth100M <--> salesSwitch.ethg++;
        salesHost2.ethg++ <--> Eth100M <--> salesSwitch.ethg++;
        salesHost3.ethg++ <--> Eth100M <--> salesSwitch.ethg++;
        adminHost1.ethg++ <--> Eth100M <--> adminSwitch.ethg++;
        adminHost2.ethg++ <--> Eth100M <--> adminSwitch.ethg++;
        adminHost3.ethg++ <--> Eth100M <--> adminSwitch.ethg++;
        marketingHost1.ethg++ <--> Eth100M <--> marketingSwitch.ethg++;
        marketingHost2.ethg++ <--> Eth100M <--> marketingSwitch.ethg++;
        marketingHost3.ethg++ <--> Eth100M <--> marketingSwitch.ethg++;
        engineeringSwitch.ethg++ <--> Eth100M <--> router.ethg[0];
        managementSwitch.ethg++ <--> Eth100M <--> router.ethg[1];
        salesSwitch.ethg++ <--> Eth100M <--> router.ethg[2];
        adminSwitch.ethg++ <--> Eth100M <--> router.ethg[3];
        marketingSwitch.ethg++ <--> Eth100M <--> router.ethg[4];
}
