package iut_lab_net.simulations;

import inet.networklayer.configurator.ipv4.Ipv4FlatNetworkConfigurator;
import inet.node.inet.StandardHost;
import inet.node.ethernet.EthernetHost;
import inet.node.ethernet.EthernetHub;
import inet.node.ethernet.EthernetSwitch;
import ned.IdealChannel;
import ned.DatarateChannel;

@license(LGPL);
//
// TODO documentation
//
network LabNetwork
{
    @display("bgb=1183,712");
    types:
        channel C extends DatarateChannel {
            datarate = 100Mbps;
            delay = 10us;
        }
    submodules:
        coreSwitch: EthernetSwitch {
            @display("p=463,224");
        }

        lab1Switch: EthernetSwitch {
            @display("p=199,224");
        }

        lab2Switch: EthernetSwitch {
            @display("p=329,121");
        }

        lab3Switch: EthernetSwitch {
            @display("p=621,121");
        }

        lab4Switch: EthernetSwitch {
            @display("p=736,224");
        }

        lab5Switch: EthernetSwitch {
            @display("p=463,382");
        }

        host1_1: StandardHost {
            @display("p=86,160");
        }

        host1_2: StandardHost {
            @display("p=86,291");
        }

        host2_1: StandardHost {
            @display("p=238,49");
        }

        host2_2: StandardHost {
            @display("p=424,49");
        }

        host3_1: StandardHost {
            @display("p=560,49");
        }

        host3_2: StandardHost {
            @display("p=724,49");
        }

        host4_1: StandardHost {
            @display("p=863,130");
        }

        host4_2: StandardHost {
            @display("p=863,306");
        }

        host5_1: StandardHost {
            @display("p=385,492");
        }

        host5_2: StandardHost {
            @display("p=582,492");
        }

        ipv4FlatNetworkConfigurator: Ipv4FlatNetworkConfigurator {
            @display("p=1061,594");
        }
    connections:

        host1_1.ethg++ <--> C <--> lab1Switch.ethg++;
        host1_2.ethg++ <--> C <--> lab1Switch.ethg++;

        host2_1.ethg++ <--> C <--> lab2Switch.ethg++;
        host2_2.ethg++ <--> C <--> lab2Switch.ethg++;

        host3_1.ethg++ <--> C <--> lab3Switch.ethg++;
        host3_2.ethg++ <--> C <--> lab3Switch.ethg++;

        host4_1.ethg++ <--> C <--> lab4Switch.ethg++;
        host4_2.ethg++ <--> C <--> lab4Switch.ethg++;

        host5_1.ethg++ <--> C <--> lab5Switch.ethg++;
        host5_2.ethg++ <--> C <--> lab5Switch.ethg++;

        lab1Switch.ethg++ <--> C <--> coreSwitch.ethg++;
        lab2Switch.ethg++ <--> C <--> coreSwitch.ethg++;
        lab3Switch.ethg++ <--> C <--> coreSwitch.ethg++;
        lab4Switch.ethg++ <--> C <--> coreSwitch.ethg++;
        lab5Switch.ethg++ <--> C <--> coreSwitch.ethg++;
}

